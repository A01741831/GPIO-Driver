
#ifndef MCAL_GPIO_H
#define MCAL_GPIO_H
#include <MKL25Z4.h>
#include <stdint.h>

/** Mask identifiers for SIM->SCGC5 clocks */
typedef enum {
    MCAL_PORTA = SIM_SCGC5_PORTA_MASK,  //máscara para habilitar reloj puerto A
    MCAL_PORTB = SIM_SCGC5_PORTB_MASK,  //máscara para habilitar reloj puerto B
    MCAL_PORTC = SIM_SCGC5_PORTC_MASK,  //máscara para habilitar reloj puerto C
    MCAL_PORTD = SIM_SCGC5_PORTD_MASK,  //máscara para habilitar reloj puerto D
    MCAL_PORTE = SIM_SCGC5_PORTE_MASK   //máscara para habilitar reloj puerto E
} MCAL_PortClockMask_t;

/** Generic port structure */
typedef struct {
    PORT_Type *port;    // PCR registers
    GPIO_Type *gpio;    // PDDR/PSOR/PCOR/PDIR registers
    MCAL_PortClockMask_t clk_mask;
} MCAL_GPIO_Port_t;

/**
 * Enable clock for given port
 *  	*port_info -> puntero a la estructura con la información del puerto
 */
void MCAL_GPIO_EnableClock(const MCAL_GPIO_Port_t *port_info);

/**
 * Configure pin as digital output
 *  	*port_info -> puntero a la estructura con la información del puerto
 *  	pin -> pin dentro del puerto
 */
void MCAL_GPIO_ConfigOutput(const MCAL_GPIO_Port_t *port_info, uint32_t pin);

/**
 * Configure pin as digital input (with pull-up)
 * 		*port_info -> puntero a la estructura con la información del puerto
 * 		pin -> pin dentro del puerto
 */
void MCAL_GPIO_ConfigInput(const MCAL_GPIO_Port_t *port_info, uint32_t pin);

/**
 * Write pin: value=1 sets pin, value=0 clears pin
 * 		*port_info -> puntero a la estructura con la información del puerto
 * 		pin -> pin dentro del puerto
 * 		value -> valor del estado
 */
void MCAL_GPIO_WritePin(const MCAL_GPIO_Port_t *port_info, uint32_t pin, uint8_t value);

/**
 * Read pin: returns 1 if high, 0 if low
 * 		*port_info -> puntero a la estructura con la información del puerto
 * 		pin -> pin dentro del puerto
 */
uint8_t MCAL_GPIO_ReadPin(const MCAL_GPIO_Port_t *port_info, uint32_t pin);

/**
 * Configure Alternate functions
 * 		*port_info -> puntero a la estructura con la información del puerto
 * 		pin -> pin dentro del puerto
 * 		alt_func -> función alternativa (el mux)
 * 		flag -> bandera para configuración adicional del pin (como pull-ups e interrupciones)
 */
void MCAL_GPIO_ConfigAltFunction(const MCAL_GPIO_Port_t *port_info, uint32_t pin, uint32_t alt_func, uint32_t flag);

#endif // MCAL_GPIO_H
