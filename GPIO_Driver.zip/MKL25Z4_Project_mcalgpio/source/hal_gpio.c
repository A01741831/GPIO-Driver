/*
 * hal_gpio.c
 *
 *  Created on: 21 may. 2025
 *      Author: anarg
 */
#include "hal_gpio.h"

void HAL_GPIO_InitOutput(const MCAL_GPIO_Port_t *port_info, uint32_t pin) {
    MCAL_GPIO_EnableClock(port_info);                              //habilitar reloj para puerto
    MCAL_GPIO_ConfigOutput(port_info, pin);                        //configurar pin como output
}

void HAL_GPIO_InitInput(const MCAL_GPIO_Port_t *port_info, uint32_t pin) {
	MCAL_GPIO_EnableClock(port_info);
	MCAL_GPIO_ConfigInput(port_info, pin);                         //configurar pin como input
}

void HAL_GPIO_InitAltFunction(const MCAL_GPIO_Port_t *port_info, uint32_t pin, uint32_t alt_func, uint32_t flag) {
    MCAL_GPIO_EnableClock(port_info);
    MCAL_GPIO_ConfigAltFunction(port_info, pin, alt_func, flag);   //configurar pin con función alternativa y bandera
}

void HAL_GPIO_Write(const MCAL_GPIO_Port_t *port_info, uint32_t pin, uint8_t state) {
	MCAL_GPIO_WritePin(port_info, pin, state);                     //escribir estado en pin
}

uint8_t HAL_GPIO_Read(const MCAL_GPIO_Port_t *port_info, uint32_t pin) {
	MCAL_GPIO_ReadPin(port_info, pin);                             //leer estado de pin
}
