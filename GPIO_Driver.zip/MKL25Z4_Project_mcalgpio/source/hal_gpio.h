/*
 * hal_gpio.h
 *
 *  Created on: 21 may. 2025
 *      Author: anarg
 */

#ifndef HAL_GPIO_H
#define HAL_GPIO_H
#include "mcal_gpio.h"
#include <stdint.h>

/**
 * Initialize a GPIO pin for digital output
 * 		*port_info -> puntero a la estructura con la información del puerto
 *  	pin -> pin dentro del puerto
 */
void HAL_GPIO_InitOutput(const MCAL_GPIO_Port_t *port_info, uint32_t pin);

/**
 * Initialize a GPIO pin for digital input
 * 		*port_info -> puntero a la estructura con la información del puerto
 *  	pin -> pin dentro del puerto
 */
void HAL_GPIO_InitInput(const MCAL_GPIO_Port_t *port_info, uint32_t pin);

/**
 * Initialize a GPIO pin for alternate functions
 *  	*port_info -> puntero a la estructura con la información del puerto
 *  	pin -> pin dentro del puerto
 *  	alt_func -> el valor de la función alternativa (el mux depende de la función: MUX(1) para GPIO, MUX(2) para UART)
 *  	flag -> banderas adicionales para la configuración del pin (pull-ups e interrupciones)
 */
void HAL_GPIO_InitAltFunction(const MCAL_GPIO_Port_t *port_info, uint32_t pin, uint32_t alt_func, uint32_t flag);

/**
 * Set the GPIO pin state
 *  	*port_info -> puntero a la estructura con la información del puerto
 *  	pin -> pin dentro del puerto
 *  	state -> el estado del pin
 */
void HAL_GPIO_Write(const MCAL_GPIO_Port_t *port_info, uint32_t pin, uint8_t state);

/**
 * Read the GPIO pin state
 *  	*port_info -> puntero a la estructura con la información del puerto
 *  	pin -> pin dentro del puerto
 */
uint8_t HAL_GPIO_Read(const MCAL_GPIO_Port_t *port_info, uint32_t pin);


#endif // HAL_GPIO_H


