#include "hal_gpio.h"
#include <MKL25Z4.h>

// Example port definitions
static const MCAL_GPIO_Port_t PORTB_INFO = {PORTB, PTB, MCAL_PORTB};
static const MCAL_GPIO_Port_t PORTD_INFO = {PORTD, PTD, MCAL_PORTD};

// LED and button pin definitions
#define LED_PIN    18
//PTB19=verde
//PTB18=rojo
//PTB1=azul
#define BUTTON_PIN    2

// ON/OFF Macros
#define ON 1
#define OFF 0
#define LED_STATE_ON_HW    OFF
#define LED_STATE_OFF_HW    ON
volatile uint8_t boton_estado=1;

typedef enum {
	GPIO_DIR_INPUT,
	GPIO_DIR_OUTPUT,
	GPIO_DIR_ALT1,
	GPIO_DIR_ALT2,
	GPIO_DIR_ALT3,
	GPIO_DIR_ALT4,
	GPIO_DIR_ALT5,
	GPIO_DIR_ALT6,
	GPIO_DIR_ALT7
} GPIO_Direction_t;

typedef struct {
	const MCAL_GPIO_Port_t *port_info; //apuntador a la información del puerto
	uint32_t pin;                      //pin
	GPIO_Direction_t direction;        //dirección, GPIO, o alternativas**
	uint32_t flag;                     //alternativas***
} GPIO_Config_t;

static const GPIO_Config_t config_table[] = {
		{&PORTB_INFO, LED_PIN, GPIO_DIR_OUTPUT},   //se configura el pin del LED como GPIO output en el puerto D
		{&PORTB_INFO, BUTTON_PIN, GPIO_DIR_INPUT}  //se configura el pin del botón como GPIO input en el puerto B
};

void HAL_GPIO_Driver_Init(const GPIO_Config_t *config_table, uint32_t num_entries){
	for(uint32_t i=0; i < num_entries; i++){
		if(config_table[i].direction == GPIO_DIR_OUTPUT){
			HAL_GPIO_InitOutput(config_table[i].port_info, config_table[i].pin); //se inicializa output con la función HAL
		} else if(config_table[i].direction == GPIO_DIR_INPUT){
			HAL_GPIO_InitInput(config_table[i].port_info, config_table[i].pin);  //se inicializa input con la función HAL
		} else { //alternativas***
			uint32_t alt_func = config_table[i].direction - GPIO_DIR_ALT1 + 1;
			HAL_GPIO_InitAltFunction(config_table[i].port_info, config_table[i].pin, alt_func, config_table[i].flag);
		}
	}
};

int main(void) {

	HAL_GPIO_Driver_Init(config_table, sizeof(config_table)/sizeof(GPIO_Config_t)); //se inicializan todos los elementos en config_table

    while(1) {
    	boton_estado=HAL_GPIO_Read(&PORTB_INFO, BUTTON_PIN);        //se le asigna el estado del botón a una variable
    	if(boton_estado == 0){
    		HAL_GPIO_Write(&PORTB_INFO, LED_PIN,LED_STATE_ON_HW);   //si el estado es 0, el led se prende
    	}
    	else{
    		HAL_GPIO_Write(&PORTB_INFO, LED_PIN,LED_STATE_OFF_HW);  //si el estado es 1, el led se apaga
    	}
    }
    return 0 ;
}

