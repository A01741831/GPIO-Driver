/*
 * mcal_gpio.c
 *
 *  Created on: 21 may. 2025
 *      Author: anarg
 */

#include "mcal_gpio.h"

/**
 * Enable clock for given port
 * 		Al poner a 1 el bit correspondiente (ej. SIM_SCGC5_PORTB_MASK para Port B),
 * 		se habilita el suministro de reloj a ese periférico.
 */
void MCAL_GPIO_EnableClock(const MCAL_GPIO_Port_t *port_info) {
    SIM->SCGC5 |= port_info->clk_mask;            //registro System Clock Gating Control Register 5
}

/**
 * Configure pin as digital output
 * 		al poner el mux en 1, configura el pin como GPIO
 * 		(1UL << pin) crea una máscara con un 1 en la posición del bit del pin, haciendolo pin de salida
 */
void MCAL_GPIO_ConfigOutput(const MCAL_GPIO_Port_t *port_info, uint32_t pin) {
    port_info->port->PCR[pin] = PORT_PCR_MUX(1);
    port_info->gpio->PDDR |= (1UL << pin);
}

/**
 * Configure pin as digital input (with pull-up)
 * 		al poner el mux en 0 se configura como GPIO
 * 		~(1UL << pin) crea una máscara con un 0 en la posición del bit del pin, haciendolo pin de entrada
 *      PORT_PCR_PE(1) habilita el resistor pull (Pull Enable)
 *      PORT_PCR_PS(1) selecciona el tipo de resistor pull: 1 para Pull-Up, 0 para Pull-Down
 */
void MCAL_GPIO_ConfigInput(const MCAL_GPIO_Port_t *port_info, uint32_t pin) {
	port_info->port->PCR[pin] = PORT_PCR_MUX(1) | PORT_PCR_PE(1) | PORT_PCR_PS(1);
	port_info->gpio->PDDR &= ~(1UL << pin);
}

/**
 * Write pin: value=1 sets pin, value=0 clears pin
 * 		escribe un estado alto o bajo en un pin de salida
 */
void MCAL_GPIO_WritePin(const MCAL_GPIO_Port_t *port_info, uint32_t pin, uint8_t value) {
	if(value){
		port_info->gpio->PSOR = (1UL << pin);  //set
	} else {
		port_info->gpio->PCOR = (1UL << pin);  //clear
	}
}

/**
 * Read pin: returns 1 if high, 0 if low
 * 		leer registro (PDIR) del pin
 */
uint8_t MCAL_GPIO_ReadPin(const MCAL_GPIO_Port_t *port_info, uint32_t pin) {
	return (port_info->gpio->PDIR & (1UL << pin)) ? 1 : 0; //devuelve
}

/*
 * configurar un pin para una función alternativa
 * 		establece los bits del MUX para seleccionar función
 */
void MCAL_GPIO_ConfigAltFunction(const MCAL_GPIO_Port_t *port_info, uint32_t pin, uint32_t alt_func, uint32_t flag) {
    port_info->port->PCR[pin] = PORT_PCR_MUX(alt_func) | flag; // si la función alternativa es GPIO (alt_func == 1) y se ha habilitado el pull resistor (flag & PORT_PCR_PE(1)), entonces se asegura de que el pin esté configurado como entrada en el PDDR
    if(alt_func == 1) {
        if(flag & PORT_PCR_PE(1)) {
            port_info->gpio->PDDR &= ~(1UL << pin); //input
        }
    }
}

